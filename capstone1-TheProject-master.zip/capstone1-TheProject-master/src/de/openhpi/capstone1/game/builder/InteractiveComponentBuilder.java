package de.openhpi.capstone1.game.builder;

import processing.core.PApplet;

public class InteractiveComponentBuilder {
	public static InteractiveComponent create(PApplet applet, String type) {
		InteractiveComponent component = null;
		//TODO build components
		
		return component;
	}
}
