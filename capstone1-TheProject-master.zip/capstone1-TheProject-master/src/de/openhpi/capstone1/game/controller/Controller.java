package de.openhpi.capstone1.game.controller;

public interface Controller {
	void handleEvent();
}
