package de.openhpi.capstone1.game.starter;


import processing.core.PApplet;

public class TheApp extends PApplet {

	@Override
	public void settings() {
		
	}

	@Override
	public void setup() {  // setup() runs once
		
	}

	@Override
	public void draw() {  // draw() loops forever, until stopped

	}
	
	//Add further user interaction as necessary
	@Override
	public void mouseClicked() {

	}
}
